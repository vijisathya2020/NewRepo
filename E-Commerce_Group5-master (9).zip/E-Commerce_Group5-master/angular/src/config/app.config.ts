export const config = {
    issuer: 'https://dev-14334923.okta.com',
    apiBaseURL: "https://dev-14334923.okta.com",
    clientId: '0oa69roih09zCpxsQ5d7'
  };