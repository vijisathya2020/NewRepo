export class User {
  userId: number
  // username
  // password
  // email
  // roles
}
