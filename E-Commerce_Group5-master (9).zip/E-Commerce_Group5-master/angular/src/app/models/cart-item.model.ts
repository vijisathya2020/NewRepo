import { Product } from "./product.model"

export class CartItem {
  amt!: number
  product!: Product
}
