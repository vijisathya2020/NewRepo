import { Product } from "./product.model"

export class OrderItem {
  amt?: number
  product?: Product
}
