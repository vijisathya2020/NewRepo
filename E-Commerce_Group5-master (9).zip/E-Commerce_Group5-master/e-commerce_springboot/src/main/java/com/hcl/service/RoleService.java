//package com.hcl.service;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.hcl.entity.Role;
//import com.hcl.repo.RoleRepository;
//
//@Service
//public class RoleService 
//{
//	@Autowired
//	private RoleRepository repo;
//	
//	public void addRole(Role r)
//	{
//		repo.save(r);
//	}
//}
