//package com.hcl.entity;
//
//public class RoleName {
//	public static final String[] roles = { "ADMIN", "DB_OPERATOR", "CUSTOMER", "GUEST" };
//}