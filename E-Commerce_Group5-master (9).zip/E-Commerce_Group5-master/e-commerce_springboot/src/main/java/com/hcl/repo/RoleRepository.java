//package com.hcl.repo;
//
////import java.util.Optional;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//
//import com.hcl.entity.Role;
////import com.hcl.entity.User;
//
// 
//public interface RoleRepository extends JpaRepository<Role, Integer>{
//	// Optional<User> findByUsername(String username);
//}
//
//
